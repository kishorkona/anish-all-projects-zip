# anish-project-new

URL:http://localhost:5050/anishtestsnew/

1. before starting change your application.properties to your project path
destination.path=<path to new project:https://github.com/kishorkona/anish-project-new-dst-files.git>/data/
