package com.anish.data;

import java.time.LocalDate;

public class DoubleHalf {
	private Integer id;
	private String childName;
	private Boolean isDouble;
	private Integer value;
	private String answer;
	private LocalDate completedDate;
	
	
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public LocalDate getCompletedDate() {
		return completedDate;
	}
	public void setCompletedDate(LocalDate completedDate) {
		this.completedDate = completedDate;
	}
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}
	public Boolean getIsDouble() {
		return isDouble;
	}
	public void setIsDouble(Boolean isDouble) {
		this.isDouble = isDouble;
	}
	public Integer getValue() {
		return value;
	}
	public void setValue(Integer value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "DoubleHalf [id=" + id + ", childName=" + childName + ", isDouble=" + isDouble + ", value=" + value
				+ ", answer=" + answer + ", completedDate=" + completedDate + "]";
	}

	
	
}
