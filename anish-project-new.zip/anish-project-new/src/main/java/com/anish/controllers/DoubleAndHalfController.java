package com.anish.controllers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.anish.data.DoubleHalf;
import com.anish.data.Word;
import com.google.gson.Gson;

@Controller
public class DoubleAndHalfController {
	
	@Autowired private Environment env;
		
	private Gson gson = new Gson();
	
	private String anish_name = "anish";
	private String ishant_name = "ishant";
	private String done_file = "double_half_done.txt";
	
	@GetMapping(value = "/doubleHalf/showQuestions/{name}")
    public ModelAndView getTakeTest(@PathVariable("name") String name) {
		ModelAndView modelAndView = new ModelAndView("double_half_view");
		modelAndView.setStatus(HttpStatus.OK);
		modelAndView.addObject("user_name_key", name);
		try {
			List<DoubleHalf> list = getDoubleHalfWords(name);
			List<Integer> completed = getDoubleHalfDoneDataForDate(name, LocalDate.now());
			List<DoubleHalf> finalList = list.stream()
					.filter(x -> {
						if(completed.contains(x.getValue())) {
							return false;
						}
						return true;
					})
					.collect(Collectors.toList());
			if(finalList.size()>0) {
				modelAndView.addObject("doubleHalf", finalList.get(0));
				modelAndView.addObject("doubleHalfTotal", finalList.size());
			}
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    	return modelAndView;
    }
	
	public List<DoubleHalf> getDoubleHalfWords(String name) {
		List<DoubleHalf> finalList = new ArrayList<DoubleHalf>();
		String arrVal = env.getProperty(name+".double");
		String[] arrValArr = arrVal.split("#");
		AtomicInteger cnt = new AtomicInteger(1);
		for(int i=0;i<arrValArr.length;i++) {
			DoubleHalf obj = new DoubleHalf();
			obj.setChildName(name);
			obj.setIsDouble(Boolean.TRUE);
			obj.setValue(Integer.valueOf(arrValArr[i]));
			obj.setCompletedDate(LocalDate.now());
			obj.setId(cnt.getAndIncrement());
			finalList.add(obj);
		}
		arrVal = env.getProperty(name+".half");
		arrValArr = arrVal.split("#");
		for(int i=0;i<arrValArr.length;i++) {
			DoubleHalf obj = new DoubleHalf();
			obj.setChildName(name);
			obj.setIsDouble(Boolean.FALSE);
			obj.setValue(Integer.valueOf(arrValArr[i]));
			obj.setCompletedDate(LocalDate.now());
			obj.setId(cnt.getAndIncrement());
			finalList.add(obj);
		}
		return finalList;
	}
	
	@PostMapping(value="/doubleHalf/submit")
    public ModelAndView completeWord(@RequestBody DoubleHalf doubleHalf) {
		try {
			if(doubleHalf.getAnswer()!=null) {
				List<DoubleHalf> finalList = getDoubleHalfWords(doubleHalf.getChildName());
				DoubleHalf doubleHalfVal = null;
				for(DoubleHalf w: finalList) {
					if(w.getValue().toString().equalsIgnoreCase(doubleHalf.getValue().toString())) {
						doubleHalfVal = w;
						break;
					}
				}
				if(doubleHalfVal != null) {
					String path = env.getProperty("destination.path");
					String doneFilePath = path+ishant_name+"/done/"+done_file;
					writeWordRecordToFile(doneFilePath, doubleHalf);
					return getTakeTest(doubleHalfVal.getChildName());	
				}
			}
        } catch (Exception ex) {
            ex.printStackTrace();
        }
		return null;
    }
	
	public void writeWordRecordToFile(String filePath, DoubleHalf word) {
    	try {   
    		Path path = Path.of(filePath);
    		Files.writeString(path, "\n"+gson.toJson(word), StandardOpenOption.APPEND);
    	} catch (Exception e) {
    		e.printStackTrace();
		}
    }
	
	public List<Integer> getDoubleHalfDoneDataForDate(String name, LocalDate date) {
		List<DoubleHalf> list = getDoubleHalfDoneData(name);
		List<Integer> finalList = list.stream()
				.filter(x -> {
					int compareValue = x.getCompletedDate().compareTo(date);
					if (compareValue > 0) {
						return false;
					} else if (compareValue < 0) {
						return false;
					} else {
						return true;
					}
				})
				.map(x -> {
					return x.getValue();
				})
				.collect(Collectors.toList());
		return finalList;
	}
	
	public List<DoubleHalf> getDoubleHalfDoneData(String name) {
		String path = env.getProperty("destination.path");
		String doneFilePath = path+name+"/done/"+done_file;
		List<DoubleHalf> lines = new ArrayList<DoubleHalf>();
		Scanner myReader = null;
		String val = null;
    	try {
    		File myObj = new File(doneFilePath);
    		myReader = new Scanner(myObj);
    		while (myReader.hasNextLine()) {
    			val = myReader.nextLine();
    			if(!StringUtils.isEmpty(val) && val.length()>0) {
        			lines.add(gson.fromJson(val, DoubleHalf.class));
    			}
    		}
    	} catch (Exception e) {
    		System.out.println("Error at Row="+val);
			e.printStackTrace();
			return null;
		} finally {
			try {
				if(myReader!=null) {
					myReader.close();
				}
			} finally {}
		}
    	return lines;
    }
}
